# VRAOD 6.5 — one-time OTA setup

The previous installed APK cannot receive this feature. Build and install the OTA-enabled APK once. Android requires the existing signing certificate for in-place installation. Previous CI debug builds may have used an ephemeral certificate; if the original signing key is unavailable, a one-time reinstall may be required. Export existing trip summaries first; the old app's summary export is not a full restorable backup. Do not uninstall if you need to preserve unexported data. If the original APK signing key is available, use that key (converted to PKCS12 with alias vraod and matching store/key password) instead of generating a new APK key.

## Configure GitHub (once)

1. Create a separate public GitHub repository called `VRAOD-updates`, initialize with README, default branch `main`. The signed UI payload is publicly readable (HTML/CSS/JS); do not put API keys or personal data in source. The existing source repository can remain private. No GitHub token is stored on the phone.
2. Run `bash scripts/create-keys.sh` on Mac or a private terminal with OpenSSL. Output under `~/vraod-private-keys` is private. Back up both keys/password securely, never commit them. If you possess the original APK signing key, use it instead of the generated APK keystore. The separate OTA signing key is trusted for the lifetime of this native build.
3. In the **source** repo Settings > Secrets and variables > Actions, create repository secrets:
   - `VRAOD_OTA_PRIVATE_KEY`: contents of `ota-key.base64`.
   - `VRAOD_APK_KEYSTORE`: contents of `apk-key.base64`.
   - `VRAOD_STORE_PASSWORD`: contents of `password.txt` (without newline).
   - `VRAOD_PUBLISH_TOKEN`: fine-grained personal access token restricted to `VRAOD-updates`, Contents read/write. Create it at https://github.com/settings/personal-access-tokens/new. Set an expiry and renew the secret before expiry. Do not paste it in chat.
4. In the Variables tab create repository variable `VRAOD_OTA_REPO` = `YOUR_GITHUB_USERNAME/VRAOD-updates`.
5. Replace `VRAOD-v6-Android.zip` in the source repository root with this ZIP. Replace `.github/workflows/build-apk.yml` in the *root repository* using the new workflow provided separately. A workflow inside a ZIP cannot trigger GitHub Actions. Push triggers UI publishing; if a run fails before configuration is complete, run again after setup.
6. Actions > Build and publish VRAOD > Run workflow > mode `native`. Download the VRAOD-APK artifact and install once. Native mode builds an APK, it does not publish the UI. Run `ui` manually if the automatic push run has not published the initial signed UI file. A phone without the configured public update endpoint can still run its bundled UI offline.

## Future UI-only changes (no APK installation)

Update the HTML, bump `versionCode` and `versionName` in `app/build.gradle` and the matching `UI_VERSION` / `UI_NAME` in `app/src/main/assets/index.html`. Keep `nativeAbi` unchanged only for compatible frontend changes. Repackage with root folder `VRAOD/` and replace the same ZIP in the source repository. Push triggers UI mode automatically; it signs and publishes the JSON without building an APK. Open VRAOD, or Settings > Check for updates. Accept the update. The same synthetic HTTPS origin serves verified local HTML, retaining existing WebView storage. Save any active draft or settings first. An active GPS recording blocks updates through the UI.

Native changes (Java, permissions, bundled fonts, SDK, launcher) require a new APK with the same signing key. For incompatible native bridge changes, increment the native ABI; older APKs will reject that UI. This version does not include native APK self-install or full backup/import. No paid API or database is required.

## Safety and recovery

The app pins the RSA public key at build time and checks the SHA256withRSA signature of the complete payload before applying it. It enforces app identity, schema, native ABI, version order and size limits. Only the signed local HTML is loaded, never a remote WebView page. The verified envelope is stored atomically in private app storage. If the process restarts before the page confirms readiness, the previous UI is restored. Settings > Restore previous UI is available after an OTA update; if no previous OTA exists it restores the bundled UI. A version that was rolled back will not be accepted again; publish a higher version. The readiness check is a startup safeguard, not a guarantee against all runtime bugs. Keep the source repository and signing keys trusted; only deploy reviewed frontend code, because the signed UI can call the native bridge. Public repo access is for retrieval only, token is in GitHub Actions secrets.

Validation: packaging/signature and tamper rejection, Java PKCS12 reading, YAML parse, JavaScript syntax, and simulated UI check/cancel/confirm tested. Real Android compilation, OTA networking, native rollback and on-device storage retention still require testing. No generated test keys are included.
