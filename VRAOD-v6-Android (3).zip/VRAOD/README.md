# VRAOD 6.5 — signed UI updates

Start with [OTA-SETUP.md](OTA-SETUP.md). The older build instructions below are superseded by the OTA workflow.

# VRAOD 2.0 — Your road. Your ride.

Personal Android trip expense tracker (Android 11+, Java WebView, JDK 17, Android SDK 35, Gradle 8.9). No backend, account, database, or mandatory paid API. Package: `com.vraod.app`. This is a new application ID; it does not automatically migrate RoadLedger data.

## Preview and features
Open `app/src/main/assets/index.html` in a browser (a local or HTTPS web origin is recommended); native location, file picker and sharing are available after Android build. Browser storage policy may vary. MiniMax-inspired DM Sans, black pills, coral/blue cards, Garage, History, Insights. Add bike/car model or a custom model, nickname and a photo from the device. Photos are downscaled to 480px and saved as JPEG in private WebView localStorage. Select a profile and use it as the default. Trips, settings and cached exact-date rates are JSON in localStorage, no SQL or remote database. The optional personal API Mitra key is saved locally and sent only to that provider. It is not hardware-backed encrypted; never publish a shared key. Clearing app storage or uninstalling loses local data. Storage is finite and writes check for quota failure; use share/export for a text record.

## Price strategy
- India Petroleum API (`https://india-petroleum-api.vercel.app/v1/prices`): no key, PPAC-derived IndianOil indicative daily prices for Delhi, Mumbai, Chennai and Kolkata, regular petrol and diesel only. Exact date match; no substitute with latest price. Attribution shown with rate.
- API Mitra (`https://api.apimitra.in/fuel/history`): attempts keyless history, optional key saved once if required; city/date match, supported cities only, up to 90 days. Free access/limits may change. Never uses generic rates for a branded premium grade.
- India Fuel Pumps public dataset (`https://github.com/ForceGT/india-fuel-pumps`): finds stations using GPS or built-in city centres, fetches index and surrounding geographic shards only. Choose actual outlet, brand and grade. An exact product and capture calendar date must match before an indicative snapshot is applied. A capture date is not proof of price-effective date or final receipt price. Snapshot may not be fresh, fields may be absent, and API access is best effort. Shell outlet records do not publish grade prices; enter actual price if unavailable. Regular and premium variants never silently substitute for each other. Some listed product variants may not be sold at every outlet. Custom grade option for Other and Nayara is manual. Saved receipt prices are reused only for matching city/date/brand/grade/station key. Users can override any quote.
- Third-party sources may stop working; no guarantee of nationwide historical or premium pricing. No website restrictions are bypassed. Native allowlist restricts network calls to these JSON endpoints. Provider responses are capped at 16 MB.

## Route card
No map SDK or map API. GPS track (precise location permission) or GPX import generates a static vector route on a neutral grid; **not a street basemap**. Start GPS before trip, keep app visible and screen on; Android stops recording when app backgrounds, and resume is manual. Do not operate phone while driving. For reliable background ride recording, use a GPX recorded by a separate tracker and import at completion; background foreground-service tracking is not implemented. Trip distance is entered manually. Start/destination text alone cannot reconstruct actual path; no fictitious route is drawn. Imported routes up to 8MB are sampled to at most ~5000 points. Routes are stored locally with saved trip; route coordinates are not transmitted to map services. Nearby fuel lookup downloads a coarse geographic cell from public GitHub data and Android reverse geocoding can use the device's geocoder service. No continuous remote GPS tracking.

## Build without Android Studio (later)
When design is approved, create a GitHub repository and upload the **contents of the VRAOD folder** to its root (including `.github/workflows/build-apk.yml`, `settings.gradle`, `app/`, `build.gradle`). Do not commit personal API keys. GitHub Actions → Build VRAOD APK → Run workflow; download the `VRAOD-APK` artifact and extract `VRAOD.apk`. A private repo's usage is subject to account limits. This workflow has not run here. Install the debug APK on Samsung by permitting installation from My Files as needed; restore the security settings afterwards. The APK is not included in the ZIP.

## Validation status
Browser JS syntax checked; mobile Chromium smoke test using mocked localStorage verified profile creation/selection, premium fuel input, GPX rendering, total calculation, saved-trip detail and history. Native Android build, device permissions, real GPS, Android file chooser and live provider responses need device testing. The browser test does not establish long-term disk persistence.

## v3.0 — Appearance and motion
- Header moon/sun control; Settings → Appearance offers Light, Dark and System. Choice is saved with the existing local settings, and native system-bar colors follow the theme. System mode follows Android's UI mode without deliberately restarting the activity.
- Native Android 12+ starting-window splash plus a short branded HTML launch animation; Android 11 uses the dark launch window. Reduced-motion preference skips the branded delay and disables nonessential animations.
- Animated currency counter, expense bars, navigation selection, vehicle switch, new fuel cards, lookup spinner, dialogs, toast, and completion check/route trace. No additional dependency or paid service.
- Browser UI checks (inline Chromium document, mocked localStorage and network blocked): theme toggles, system appearance, settings write, calculator, fuel stops, garage, GPX import and trip completion. Native APK compilation, device behavior and live fuel providers remain unverified.

## VRAOD 4.0 — Galaxy-inspired interaction update
- Michroma display/brand and Encode Sans Expanded body, fetched as OFL font assets by the existing GitHub build workflow; browser preview uses Google Fonts and falls back when offline.
- Custom animated SVG glyphs, direction-aware screen entrances, rounded floating navigation, touch feedback and bottom sheets for selection, errors and confirmations.
- Automatic price failures remain inline to avoid interrupting typing; explicit fetch, GPS, photo, GPX, validation and storage failures display dialogs.
- Android Back closes open sheets or returns to Trip; native haptic feedback respects device settings.
- Existing local storage keys, fuel providers, route trace and vehicle records retained. Native compilation and device tests are still required.

## VRAOD 5.0 — icon repair and browser-only build
All 15 glyphs refreshed, explicit SVG pivots for clock/gear/wheels, paired bar outlines and fills animate together, no competing root SVG animations. Rapid navigation taps cancel prior exit animation; last selection wins. Existing storage keys and package ID are unchanged. Reduced-motion rules remain enabled.

For browser-only deployment, create a private GitHub repository with README, upload `VRAOD-v6-Android.zip` to its root (keep the name exactly), then create `.github/workflows/build-apk.yml` using the included workflow contents. The workflow detects the ZIP and extracts it automatically. Alternatively extract the project and push its contents normally; the same workflow supports both. Do not upload personal API keys. In Actions download `VRAOD-APK` from a successful run and extract `VRAOD.apk`. Debug APK signing may vary between fresh cloud runners; to update without losing local data, configure a persistent private signing key before distributing subsequent builds. Native compilation is not verified here.

## VRAOD 6.0 — Glass navigation
Borderless sticky header with a downward fading backdrop blur, and translucent floating bottom navigation in both themes. No changes to trip logic, storage, or icons.

## V6.2 — Card motion and current location

- Active-page cards animate once as they enter the scroll viewport, with 65ms stagger (capped at 195ms), 480ms rise/fade, and reduced-motion support. The fixed navigation shell is unchanged.
- The New Trip screen now has a Current location card immediately below the expense summary. Tap Use my location to request Android location permission and fetch a one-time location fix. Tap the target icon to refresh; +/- zooms the map. Location is not saved in trip history by this feature.
- The map uses a local Web Mercator tile renderer with OpenStreetMap Standard tiles, no third-party JavaScript, no SDK/API key and no background tile prefetch. Attribution is visible on the map, Android WebView uses its normal HTTP cache, and the app identifies itself in the User-Agent. This public service is intended for light personal use, subject to https://operations.osmfoundation.org/policies/tiles/ . Internet is required for uncached street tiles; a location marker/grid and clear status remain if the tiles fail. The map tile service receives the viewed tile area. Existing saved GPS/GPX route diagrams remain offline and unchanged.
- Existing package ID and local storage keys are unchanged; versionCode 8, versionName 6.2. The ZIP is deliberately named VRAOD-v6-Android.zip for compatibility with the existing GitHub workflow. Replacing that file triggers the existing build. Updates require the same signing certificate as the installed APK; do not uninstall if local data needs to be preserved.
- Browser verification used simulated GPS and image load/error callbacks (not live map imagery); native Android build and real-device GPS remain to be verified.

## 6.3 — No Slop UI refinement
Compact headers, flat bordered 12px cards, vehicle-accented expense summary, list-based statistics, compact garage and dialogs, 180ms opacity stagger. Explicit design exceptions: two requested fonts, animated icons, splash, frosted header and bottom pill, and subtle sheet motion. No runtime dependencies added. Android package name and storage keys unchanged. Native build/device tests pending.

## V6.4
Restores the coral/blue expense hero card and adds slow decorative loops, paused offscreen, when the document is hidden, or when reduced motion is requested. Other UI and functionality unchanged. Existing GitHub ZIP workflow remains compatible.
