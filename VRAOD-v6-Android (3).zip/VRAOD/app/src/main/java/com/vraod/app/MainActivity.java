package com.vraod.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowInsets;
import android.webkit.*;
import android.widget.FrameLayout;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private WebView web;
    private UiUpdates updates;
    private final ExecutorService updateWorker=Executors.newSingleThreadExecutor();
    private FrameLayout root;
    private final ExecutorService workers = Executors.newFixedThreadPool(3);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private static final String HOME = "https://appassets.androidplatform.net/index.html";
    private CancellationSignal locationSignal;
    private boolean locating;
    private CancellationSignal mapSignal;
    private String pendingMapId;
    private android.webkit.ValueCallback<Uri[]> fileCallback;
    private android.location.LocationListener trackListener;
    private boolean trackingRequested;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        updates=new UiUpdates(this);
        root = new FrameLayout(this); root.setBackgroundColor(Color.rgb(16,16,18));
        web = new WebView(this); web.setBackgroundColor(Color.rgb(16,16,18)); root.addView(web, new FrameLayout.LayoutParams(-1,-1)); setContentView(root);
        root.setOnApplyWindowInsetsListener((v,insets)-> {
            android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
            if (android.os.Build.VERSION.SDK_INT >= 35) v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            return insets;
        });
        applySystemBars(true);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(false); s.setAllowContentAccess(false); s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW); s.setUserAgentString(s.getUserAgentString()+" VRAOD/6.5 (com.vraod.app)"); s.setCacheMode(WebSettings.LOAD_DEFAULT);
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req){
                if (HOME.equals(req.getUrl().toString())) {
                    try { byte[] html=updates.html();
                        WebResourceResponse response=new WebResourceResponse("text/html","UTF-8",html==null?getAssets().open("index.html"):new ByteArrayInputStream(html));
                        response.setResponseHeaders(Collections.singletonMap("Cache-Control","no-store"));return response;
                    } catch(IOException e){return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0]));}
                }
                String path=req.getUrl().getPath();
                if ("https".equals(req.getUrl().getScheme()) && "appassets.androidplatform.net".equals(req.getUrl().getHost()) && path != null && path.matches("/fonts/(Michroma-Regular|EncodeSansExpanded-(Regular|Medium|SemiBold|Bold))\\.ttf")) {
                    try { return new WebResourceResponse("font/ttf",null,getAssets().open(path.substring(1))); } catch(IOException e){return null;}
                }
                if ("appassets.androidplatform.net".equals(req.getUrl().getHost())) return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0]));
                if(req.isForMainFrame()) return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0]));
                return null;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req){
                return !HOME.equals(req.getUrl().toString());
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params){
                if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;
                try{startActivityForResult(params.createIntent(),31);return true;}catch(Exception e){fileCallback=null;cb.onReceiveValue(null);return true;}
            }
        }); web.addJavascriptInterface(new Bridge(),"AndroidRoad"); web.loadUrl(HOME);
    }
    private void js(String function, String... values){
        StringJoiner args = new StringJoiner(","); for(String value:values) args.add(JSONObject.quote(value));
        runOnUiThread(()-> { if(web != null) web.evaluateJavascript("window."+function+"("+args+")",null); });
    }
    private boolean isDeviceDark(){return (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK)==android.content.res.Configuration.UI_MODE_NIGHT_YES;}
    private void applySystemBars(boolean dark){
        int color=dark?Color.rgb(16,16,20):Color.rgb(243,243,247);
        root.setBackgroundColor(color); web.setBackgroundColor(color);
        getWindow().setStatusBarColor(color); getWindow().setNavigationBarColor(color);
        getWindow().setNavigationBarContrastEnforced(false);
        android.view.WindowInsetsController controller=getWindow().getInsetsController();
        int mask=android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS|android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
        if(controller!=null)controller.setSystemBarsAppearance(dark?0:mask,mask);
    }
    @Override public void onConfigurationChanged(android.content.res.Configuration config){super.onConfigurationChanged(config);if(web!=null)web.evaluateJavascript("if(typeof applyTheme==='function')applyTheme()",null);}
    @Override public void onBackPressed(){
        if(web==null){super.onBackPressed();return;}
        web.evaluateJavascript("typeof window.vraodBack==='function' && window.vraodBack()",result->{if(!"true".equals(result))super.onBackPressed();});
    }
    private class Bridge {
        @JavascriptInterface public boolean otaConfigured(){return updates.configured();}
        @JavascriptInterface public int otaVersion(){return updates.current();}
        @JavascriptInterface public boolean otaCanRollback(){return updates.canRollback();}
        @JavascriptInterface public void otaCheck(){updateWorker.execute(()->{try{js("roadUpdateResult","",updates.check().toString());}catch(Exception e){js("roadUpdateResult",e.getMessage()==null?"Update check failed":e.getMessage(),"");}});}
        @JavascriptInterface public void otaApply(int version){updateWorker.execute(()->{try{updates.apply(version);runOnUiThread(()->{if(web!=null){endTrack();web.loadUrl(HOME);}});}catch(Exception e){js("roadUpdateApplyError",e.getMessage()==null?"Update failed":e.getMessage());}});}
        @JavascriptInterface public void otaReady(int version){updateWorker.execute(()->updates.ready(version));}
        @JavascriptInterface public void otaRollback(){updateWorker.execute(()->{if(updates.rollback())runOnUiThread(()->{if(web!=null){endTrack();web.loadUrl(HOME);}});else js("roadUpdateApplyError","No previous update to restore");});}

        @JavascriptInterface public void tapFeedback(){runOnUiThread(()->web.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK));}
        @JavascriptInterface public boolean isSystemDark(){return isDeviceDark();}
        @JavascriptInterface public void applyAppearance(String mode, boolean dark){runOnUiThread(()->applySystemBars(dark));}

        @JavascriptInterface public void lookup(String id,String url,String key){
            workers.execute(()->{
                HttpURLConnection conn=null;
                try {
                    URL u=new URL(url); String host=u.getHost(); String path=u.getPath();
                    if(!"https".equals(u.getProtocol()) || !( (host.equals("india-petroleum-api.vercel.app") && path.equals("/v1/prices")) || (host.equals("api.apimitra.in") && path.equals("/fuel/history")) || (host.equals("raw.githubusercontent.com") && path.matches("/ForceGT/india-fuel-pumps/main/dataset/(index\\.json|shards/[a-z0-9.]+\\.json)")) )) throw new IOException("Unsupported provider");
                    conn=(HttpURLConnection)u.openConnection(); conn.setInstanceFollowRedirects(false); conn.setConnectTimeout(10000); conn.setReadTimeout(12000); conn.setRequestProperty("Accept","application/json");
                    if(host.equals("api.apimitra.in")&&!key.isEmpty()) conn.setRequestProperty("x-api-key",key);
                    if(conn.getResponseCode()!=200) throw new IOException("Provider returned HTTP "+conn.getResponseCode());
                    try(InputStream in=conn.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()){
                        byte[] b=new byte[4096]; int n; while((n=in.read(b))!=-1){out.write(b,0,n); if(out.size()>16000000) throw new IOException("Response too large");}
                        js("roadResponse",id,"",out.toString(StandardCharsets.UTF_8.name()));
                    }
                } catch(Exception e){js("roadResponse",id,e.getMessage()==null?"Lookup failed":e.getMessage(),"");} finally {if(conn!=null)conn.disconnect();}
            });
        }
        @JavascriptInterface public void locate(){runOnUiThread(()->{
            if(checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},7);} else getCity();
        });}
        @JavascriptInterface public void locateMap(String id){runOnUiThread(()->{
            if(pendingMapId!=null){js("roadMapLocation",id,"","","","A location request is already running. Try again shortly.");return;}
            pendingMapId=id;
            if(checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},9);}else getMapPosition();
        });}
        @JavascriptInterface public void mapAttribution(){runOnUiThread(()->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.openstreetmap.org/copyright")));}catch(Exception ignored){}});}
        @JavascriptInterface public void startTrack(){runOnUiThread(()->{trackingRequested=true;if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},8);else beginTrack();});}
        @JavascriptInterface public void stopTrack(){runOnUiThread(()->endTrack());}
        @JavascriptInterface public void share(String text){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(i,"Share trip"));});}
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grants){super.onRequestPermissionsResult(request,permissions,grants); if(request==9){if(checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED||checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED)getMapPosition();else finishMapPosition(pendingMapId,null,"Location permission denied. Allow location access and retry.");}if(request==8){if(trackingRequested&&checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED)beginTrack();else{trackingRequested=false;js("roadTrackError","Precise GPS permission is required.");}}if(request==7){if(checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED)getCity();else js("roadLocation","","Location permission denied. Enter city manually.");}}
    private void finishMapPosition(String id,Location location,String error){
        if(id==null||!id.equals(pendingMapId))return;
        pendingMapId=null;if(mapSignal!=null){mapSignal.cancel();mapSignal=null;}
        if(location==null){js("roadMapLocation",id,"","","",error);return;}
        js("roadMapLocation",id,Double.toString(location.getLatitude()),Double.toString(location.getLongitude()),Float.toString(location.getAccuracy()),"");
    }
    private void getMapPosition(){
        final String id=pendingMapId;if(id==null)return;
        try{
            LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
            boolean fine=checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
            String provider=fine&&lm.isProviderEnabled(LocationManager.GPS_PROVIDER)?LocationManager.GPS_PROVIDER:LocationManager.NETWORK_PROVIDER;
            if(!lm.isProviderEnabled(provider)){finishMapPosition(id,null,"Turn on location services and try again.");return;}
            mapSignal=new CancellationSignal();final CancellationSignal signal=mapSignal;
            handler.postDelayed(()->{if(mapSignal==signal)finishMapPosition(id,null,"Location timed out. Try again outdoors or enable network location.");},20000);
            lm.getCurrentLocation(provider,signal,getMainExecutor(),location->{if(mapSignal==signal)finishMapPosition(id,location,location==null?"No location fix available. Try again.":"");});
        }catch(Exception e){finishMapPosition(id,null,"Location unavailable. Check permissions and location settings.");}
    }
    private void getCity(){
        if(locating)return; locating=true;
        try {
            LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
            String provider=lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)?LocationManager.NETWORK_PROVIDER:LocationManager.GPS_PROVIDER;
            if(!lm.isProviderEnabled(provider)) throw new IllegalStateException("Turn on location or enter city manually.");
            locationSignal=new CancellationSignal(); CancellationSignal signal=locationSignal;
            handler.postDelayed(()->{if(locating && locationSignal==signal){signal.cancel();locating=false;js("roadLocation","","Location timed out. Enter city manually.");}},18000);
            lm.getCurrentLocation(provider,signal,getMainExecutor(),location->{
                if(!locating||locationSignal!=signal)return;
                if(location==null){locating=false;js("roadLocation","","Location unavailable. Enter city manually.");return;}
                workers.execute(()->{
                    String city="", error="";
                    try {
                        List<Address> results=new Geocoder(this,Locale.ENGLISH).getFromLocation(location.getLatitude(),location.getLongitude(),1);
                        if(results!=null&&!results.isEmpty()){Address a=results.get(0);city=a.getLocality();if(city==null||city.isEmpty())city=a.getSubAdminArea();}
                        if(city==null||city.isEmpty())throw new IOException("City not found. Enter it manually.");
                    }catch(Exception e){error="City lookup unavailable. Enter it manually.";city="";}
                    final String c=city,err=error;runOnUiThread(()->{if(locating&&locationSignal==signal){locating=false;js("roadLocation",c,err,Double.toString(location.getLatitude()),Double.toString(location.getLongitude()));}});
                });
            });
        } catch(Exception e){locating=false;js("roadLocation","","Location unavailable. Enter city manually.");}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==31&&fileCallback!=null){fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));fileCallback=null;}}
    private void beginTrack(){if(trackListener!=null)return;try{LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);if(!lm.isProviderEnabled(LocationManager.GPS_PROVIDER))throw new IllegalStateException("Enable GPS first");trackListener=loc->{if(loc.hasAccuracy()&&loc.getAccuracy()>80)return;js("roadTrackPoint",Double.toString(loc.getLatitude()),Double.toString(loc.getLongitude()),Long.toString(loc.getTime()));};lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,3000,8f,trackListener,Looper.getMainLooper());getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);}catch(Exception e){endTrack();js("roadTrackError",e.getMessage()==null?"GPS unavailable":e.getMessage());}}
    private void endTrack(){trackingRequested=false;if(trackListener!=null){((LocationManager)getSystemService(LOCATION_SERVICE)).removeUpdates(trackListener);trackListener=null;}getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);}
    @Override protected void onStop(){super.onStop();if(trackListener!=null){endTrack();js("roadTrackError","GPS paused because the app went to the background. Resume when ready.");}}
    @Override public void onDestroy(){endTrack();if(locationSignal!=null)locationSignal.cancel();if(mapSignal!=null)mapSignal.cancel();pendingMapId=null;workers.shutdownNow();updateWorker.shutdownNow();if(web!=null){web.destroy();web=null;}super.onDestroy();}
}
