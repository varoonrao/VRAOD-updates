package com.vraod.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;

/** Signed, single-file frontend updates. No remote page is ever loaded in WebView. */
final class UiUpdates {
    static final int ABI = 1;
    private static final int LIMIT = 2 * 1024 * 1024;
    private final Context context;
    private final SharedPreferences state;
    private final File dir;
    private final int baseline;
    private String endpoint;
    private PublicKey key;
    private volatile byte[] html;
    private volatile int current;
    private Candidate staged;
    private boolean trial;

    private static final class Candidate {
        final int version; final String name, notes; final byte[] envelope, html;
        Candidate(int v,String n,String r,byte[] e,byte[] h){version=v;name=n;notes=r;envelope=e;html=h;}
    }
    UiUpdates(Context c) {
        context=c; state=c.getSharedPreferences("vraod.ui.update.v1",Context.MODE_PRIVATE);
        dir=new File(c.getFilesDir(),"signed-ui"); dir.mkdirs();
        int b=11;
        try { b=(int)c.getPackageManager().getPackageInfo(c.getPackageName(),0).getLongVersionCode(); } catch(Exception ignored){}
        baseline=b;current=b;
        try(InputStream in=c.getAssets().open("ota-config.json")) {
            JSONObject cfg=new JSONObject(new String(read(in,16384),StandardCharsets.UTF_8));
            String repo=cfg.getString("repo");
            if(!repo.matches("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+"))throw new IOException("Invalid update repository");
            endpoint="https://raw.githubusercontent.com/"+repo+"/main/vraod-update.json";
            key=KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(Base64.decode(cfg.getString("publicKey"),Base64.DEFAULT)));
        } catch(Exception ignored){endpoint=null;key=null;}
        restore();
    }
    boolean configured(){return key!=null && endpoint!=null;}
    int current(){return current;}
    boolean canRollback(){return current>baseline;}
    byte[] html(){return html;}
    private File file(int version){return new File(dir,"ui-"+version+".json");}
    private static byte[] read(InputStream in,int max)throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
        while((n=in.read(buf))!=-1){if(out.size()+n>max)throw new IOException("Update exceeds size limit");out.write(buf,0,n);}return out.toByteArray();
    }
    private Candidate verify(byte[] envelope)throws Exception {
        if(!configured())throw new IOException("Update channel not configured");
        JSONObject outer=new JSONObject(new String(envelope,StandardCharsets.UTF_8));
        byte[] body=Base64.decode(outer.getString("payload"),Base64.DEFAULT);
        byte[] sig=Base64.decode(outer.getString("signature"),Base64.DEFAULT);
        Signature verifier=Signature.getInstance("SHA256withRSA");verifier.initVerify(key);verifier.update(body);
        if(!verifier.verify(sig))throw new SecurityException("Update signature invalid");
        JSONObject p=new JSONObject(new String(body,StandardCharsets.UTF_8));
        if(!"com.vraod.app".equals(p.getString("app"))||p.getInt("schema")!=1)throw new IOException("Unexpected update format");
        if(p.getInt("nativeAbi")!=ABI)throw new IOException("This update requires a newer Android app");
        int version=p.getInt("versionCode");String name=p.getString("versionName"),notes=p.optString("notes","");
        byte[] content=p.getString("html").getBytes(StandardCharsets.UTF_8);
        if(version<=0||content.length==0||content.length>LIMIT||name.length()>40||notes.length()>2000||!p.getString("html").startsWith("<!doctype html>"))throw new IOException("Invalid update content");
        return new Candidate(version,name,notes,envelope,content);
    }
    private Candidate load(int v)throws Exception {try(InputStream in=new FileInputStream(file(v))){Candidate c=verify(read(in,LIMIT));if(c.version!=v)throw new IOException("Version mismatch");return c;}}
    private void restore(){
        int active=state.getInt("active",0), previous=state.getInt("previous",0);
        // A process death before the new page confirms readiness restores the old page.
        if(state.getBoolean("trial",false)){active=previous;previous=0;state.edit().putInt("active",active).putInt("previous",0).putBoolean("trial",false).commit();}
        if(active>baseline)try{Candidate c=load(active);html=c.html;current=c.version;return;}catch(Exception ignored){}
        if(previous>baseline)try{Candidate c=load(previous);html=c.html;current=c.version;state.edit().putInt("active",previous).putInt("previous",0).commit();return;}catch(Exception ignored){}
        state.edit().putInt("active",0).putInt("previous",0).putBoolean("trial",false).commit();
    }
    synchronized JSONObject check()throws Exception {
        if(!configured())throw new IOException("Update channel is not configured in this APK");
        HttpURLConnection conn=(HttpURLConnection)new URL(endpoint+"?v="+System.currentTimeMillis()).openConnection();
        conn.setInstanceFollowRedirects(false);conn.setConnectTimeout(10000);conn.setReadTimeout(12000);conn.setUseCaches(false);conn.setRequestProperty("Accept","application/json");
        conn.setRequestProperty("User-Agent","VRAOD-UI-Updater/1");
        Candidate c;
        try {int status=conn.getResponseCode();if(status!=200)throw new IOException("Update server returned HTTP "+status);try(InputStream in=conn.getInputStream()){c=verify(read(in,LIMIT));}}finally{conn.disconnect();}
        int high=Math.max(current,state.getInt("high",baseline));
        JSONObject result=new JSONObject();result.put("available",c.version>high);result.put("current",current);
        if(c.version>high){staged=c;result.put("versionCode",c.version);result.put("versionName",c.name);result.put("notes",c.notes);}else staged=null;
        return result;
    }
    synchronized void apply(int version)throws Exception {
        if(staged==null||staged.version!=version||version<=Math.max(current,state.getInt("high",baseline)))throw new IOException("Check for updates again");
        Candidate c=verify(staged.envelope);
        File target=file(c.version);android.util.AtomicFile atomic=new android.util.AtomicFile(target);FileOutputStream out=null;
        try{out=atomic.startWrite();out.write(c.envelope);atomic.finishWrite(out);}catch(Exception e){if(out!=null)atomic.failWrite(out);throw e;}
        int previous=current>baseline?current:0;
        if(!state.edit().putInt("active",c.version).putInt("previous",previous).putInt("high",c.version).putBoolean("trial",true).commit())throw new IOException("Could not save update state");
        html=c.html;current=c.version;trial=true;staged=null;
    }
    synchronized void ready(int version){if(trial&&version==current){if(state.edit().putBoolean("trial",false).commit()){trial=false;prune();}}}
    synchronized boolean rollback(){
        if(current<=baseline)return false;
        int previous=state.getInt("previous",0);Candidate c=null;
        if(previous>baseline)try{c=load(previous);}catch(Exception ignored){}
        if(!state.edit().putInt("active",c==null?0:c.version).putInt("previous",0).putBoolean("trial",false).commit())return false;
        html=c==null?null:c.html;current=c==null?baseline:c.version;trial=false;staged=null;prune();return true;
    }
    private void prune(){int active=state.getInt("active",0),prev=state.getInt("previous",0);File[] files=dir.listFiles();if(files!=null)for(File f:files)if(!f.equals(file(active))&&!f.equals(file(prev)))f.delete();}
}
