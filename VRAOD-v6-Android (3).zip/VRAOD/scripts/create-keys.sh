#!/usr/bin/env bash
# Run locally or in a private Codespace. Never commit the output or share it in chat.
set -euo pipefail
umask 077
DIR="${1:-$HOME/vraod-private-keys}"
mkdir -p "$DIR"
if [ -e "$DIR/ota.pem" ] || [ -e "$DIR/vraod.p12" ]; then echo 'Existing key found; refusing to overwrite.' >&2; exit 1; fi
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:3072 -out "$DIR/ota.pem"
openssl req -new -x509 -newkey rsa:3072 -nodes -days 10000 -subj '/CN=VRAOD/' -keyout "$DIR/apk.pem" -out "$DIR/apk.crt"
openssl rand -hex 24 > "$DIR/password.txt"
openssl pkcs12 -export -inkey "$DIR/apk.pem" -in "$DIR/apk.crt" -name vraod -out "$DIR/vraod.p12" -passout "file:$DIR/password.txt"
openssl base64 -A -in "$DIR/ota.pem" > "$DIR/ota-key.base64"
openssl base64 -A -in "$DIR/vraod.p12" > "$DIR/apk-key.base64"
printf '\nSecrets are in %s (keep private and back up securely):\nVRAOD_OTA_PRIVATE_KEY = ota-key.base64\nVRAOD_APK_KEYSTORE = apk-key.base64\nVRAOD_STORE_PASSWORD = password.txt\n' "$DIR"
