#!/usr/bin/env python3
"""Build a signed, self-contained OTA envelope; private key stays outside app assets."""
import argparse, base64, json, pathlib, re, subprocess, tempfile
p=argparse.ArgumentParser();p.add_argument('--project',type=pathlib.Path,required=True);p.add_argument('--key',type=pathlib.Path,required=True);p.add_argument('--repo',required=True);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--notes',default='Interface and functionality improvements.');a=p.parse_args()
if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',a.repo):p.error('Use owner/repository for --repo')
assets=a.project/'app/src/main/assets'; html=(assets/'index.html').read_text(); gradle=(a.project/'app/build.gradle').read_text()
version=int(re.search(r'versionCode\s+(\d+)',gradle)[1]);name=re.search(r"versionName\s+'([^']+)'",gradle)[1]; abi=int(re.search(r'ABI\s*=\s*(\d+)',(a.project/'app/src/main/java/com/vraod/app/UiUpdates.java').read_text())[1])
if f'const UI_VERSION={version};' not in html or f"const UI_NAME='{name}';" not in html:raise SystemExit('Frontend and Gradle versions must match')
public=subprocess.check_output(['openssl','pkey','-in',str(a.key),'-pubout','-outform','DER'])
(assets/'ota-config.json').write_text(json.dumps({'repo':a.repo,'publicKey':base64.b64encode(public).decode()}))
body=json.dumps({'schema':1,'app':'com.vraod.app','nativeAbi':abi,'versionCode':version,'versionName':name,'notes':a.notes,'html':html},ensure_ascii=False,separators=(',',':')).encode()
with tempfile.TemporaryDirectory() as d:
    f=pathlib.Path(d)/'payload';f.write_bytes(body)
    sig=subprocess.check_output(['openssl','dgst','-sha256','-sign',str(a.key),str(f)])
    pub=pathlib.Path(d)/'pub.pem';pub.write_bytes(subprocess.check_output(['openssl','pkey','-in',str(a.key),'-pubout']))
    sigfile=pathlib.Path(d)/'sig';sigfile.write_bytes(sig)
    subprocess.run(['openssl','dgst','-sha256','-verify',str(pub),'-signature',str(sigfile),str(f)],check=True)
result=json.dumps({'payload':base64.b64encode(body).decode(),'signature':base64.b64encode(sig).decode()},separators=(',',':')).encode()
if len(result)>1024*1024:raise SystemExit('Update exceeds native size limit')
a.out.write_bytes(result)
print(f'Signed UI {name} ({version}), ABI {abi}, {len(result)} bytes')
