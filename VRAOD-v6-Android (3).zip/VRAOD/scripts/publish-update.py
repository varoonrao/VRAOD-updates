#!/usr/bin/env python3
"""Publish one atomic GitHub file update; reject accidental version downgrades."""
import base64,json,os,pathlib,re,sys,urllib.request,urllib.error
repo=os.environ['VRAOD_OTA_REPO'];token=os.environ['VRAOD_PUBLISH_TOKEN'];path=pathlib.Path(sys.argv[1]);body=path.read_bytes()
if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',repo):raise SystemExit('Invalid repo')
def version(blob):return json.loads(base64.b64decode(json.loads(blob)['payload']))['versionCode']
url=f'https://api.github.com/repos/{repo}/contents/vraod-update.json'
def request(method,url,data=None):
    r=urllib.request.Request(url,data=json.dumps(data).encode() if data else None,method=method,headers={'Authorization':f'Bearer {token}','Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','Content-Type':'application/json','User-Agent':'VRAOD-publisher'})
    with urllib.request.urlopen(r,timeout=30) as response:return json.load(response)
new=version(body);data={'message':f'Publish signed VRAOD UI {new}','content':base64.b64encode(body).decode(),'branch':'main'}
try:
    old=request('GET',url+'?ref=main');previous=base64.b64decode(old['content']);oldver=version(previous)
    if new<oldver:raise SystemExit('Refusing to publish an older version')
    if new==oldver:
        if previous==body:print('Already published');sys.exit(0)
        raise SystemExit('Increment versionCode before publishing changed content')
    data['sha']=old['sha']
except urllib.error.HTTPError as e:
    if e.code!=404:raise
request('PUT',url,data);print(f'Published UI {new} to {repo}')
